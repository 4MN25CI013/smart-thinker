$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
Set-Location $Root
if (-not (Test-Path '.venv\Scripts\python.exe')) { py -3 -m venv .venv }
.\.venv\Scripts\python.exe -m pip install -q -r requirements.txt
Push-Location frontend; npm install --silent; Pop-Location
$backend = Start-Process -PassThru -NoNewWindow -FilePath '.venv\Scripts\python.exe' -ArgumentList '-m','uvicorn','backend.app:app','--host','127.0.0.1','--port','8000'
try { Push-Location frontend; npm run dev } finally { Pop-Location; Stop-Process -Id $backend.Id -Force }

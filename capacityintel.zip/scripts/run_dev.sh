#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
if [[ ! -x .venv/bin/python ]]; then python3 -m venv .venv; fi
.venv/bin/pip install -q -r requirements.txt
(cd frontend && npm install --silent)
trap 'kill 0' EXIT
.venv/bin/python -m uvicorn backend.app:app --host 127.0.0.1 --port 8000 &
(cd frontend && npm run dev) &
wait

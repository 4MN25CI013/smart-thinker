export async function api(path) {
  const response = await fetch(path)
  if (!response.ok) {
    const detail = await response.text()
    throw new Error(detail || `${response.status} ${response.statusText}`)
  }
  return response.json()
}

export function withTenant(path, tenant) {
  if (!tenant) return path
  return `${path}${path.includes('?') ? '&' : '?'}tenant=${encodeURIComponent(tenant)}`
}

import { Component, useEffect, useMemo, useState } from 'react'
import { Activity, ChevronDown, CircleHelp, RefreshCw } from 'lucide-react'
import { api } from './api'
import Cards from './components/Cards'
import DatasetBanner from './components/DatasetBanner'
import AlertCentre from './components/AlertCentre'
import Inventory from './components/Inventory'
import ResourceDetail from './components/ResourceDetail'
import DeliveryStatus from './components/DeliveryStatus'

const defaultFilters = { resource_type: '', rack: '', risk: '', q: '', sort: 'risk' }

function DashboardApp() {
  const [tenant, setTenant] = useState('')
  const [tenants, setTenants] = useState([])
  const [dataset, setDataset] = useState(null)
  const [health, setHealth] = useState(null)
  const [summary, setSummary] = useState(null)
  const [alerts, setAlerts] = useState([])
  const [items, setItems] = useState([])
  const [notificationFeed, setNotificationFeed] = useState(null)
  const [selected, setSelected] = useState(null)
  const [audit, setAudit] = useState([])
  const [filters, setFilters] = useState(defaultFilters)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  async function loadOverview() {
    setLoading(true); setError('')
    try {
      const suffix = tenant ? `?tenant=${encodeURIComponent(tenant)}` : ''
      const resourceQuery = new URLSearchParams({ ...filters, limit: '50' })
      if (tenant) resourceQuery.set('tenant', tenant)
      const [nextHealth, nextDataset, nextSummary, nextAlerts, nextItems, nextTenants, nextNotifications] = await Promise.all([
        api('/api/health'), api(`/api/dataset${suffix}`), api(`/api/summary${suffix}`), api(`/api/alerts${tenant ? `?tenant=${encodeURIComponent(tenant)}` : ''}`), api(`/api/resources?${resourceQuery}`), api('/api/tenants'), api('/api/notifications')
      ])
      setHealth(nextHealth); setDataset(nextDataset); setSummary(nextSummary); setAlerts(nextAlerts.items); setItems(nextItems.items); setTenants(nextTenants.items); setNotificationFeed(nextNotifications)
    } catch (err) { setError(err.message || 'Unable to load the monitoring surface.') } finally { setLoading(false) }
  }

  useEffect(() => { loadOverview() }, [tenant, filters])
  useEffect(() => {
    const params = new URLSearchParams(window.location.search)
    const target = params.get('resource')
    const targetTenant = params.get('tenant')
    if (targetTenant) setTenant(targetTenant)
    if (target) setSelected(target)
  }, [])

  useEffect(() => {
    async function loadDetail() {
      if (!selected) return
      try {
        const suffix = tenant ? `?tenant=${encodeURIComponent(tenant)}` : ''
        const [forecast, auditResponse] = await Promise.all([api(`/api/resources/${encodeURIComponent(selected)}/forecast${suffix}`), api(`/api/audit?resource_id=${encodeURIComponent(selected)}${tenant ? `&tenant=${encodeURIComponent(tenant)}` : ''}`)])
        setSelected({ forecast, audit: auditResponse.items })
      } catch (err) { setError(err.message || 'Unable to load resource detail.') }
    }
    if (typeof selected === 'string') loadDetail()
  }, [selected, tenant])

  const selectedForecast = selected && typeof selected === 'object' ? selected.forecast : null
  const selectedAudit = selected && typeof selected === 'object' ? selected.audit : []
  const subtitle = useMemo(() => tenant ? `Tenant scope · ${tenant}` : 'Operator scope · all visible tenants', [tenant])

  return <div className="app-shell"><DatasetBanner dataset={dataset} health={health} /><header className="topbar"><div className="topbar-left"><div className="signal-icon"><Activity size={19} /></div><div><span className="eyebrow">AI-OPS / AO-02 · SMART THINKERS</span><h1>Seeing trouble before the capacity runs out</h1><p>{subtitle}</p></div></div><div className="topbar-actions"><label className="viewer-select"><span>Viewing as</span><select value={tenant} onChange={event => { setTenant(event.target.value); setSelected(null) }}><option value="">Operator · all tenants</option>{tenants.map(item => <option key={item} value={item}>Tenant · {item}</option>)}</select><ChevronDown size={15} /></label><button className="refresh-button" onClick={loadOverview} disabled={loading}><RefreshCw size={16} className={loading ? 'spin' : ''} /> Refresh</button></div></header>{error && <div className="error-banner"><CircleHelp size={16} /> {error}</div>}{loading && !summary ? <div className="loading-state"><div className="loading-ring"></div><span>Loading the latest assessment…</span></div> : <main><Cards summary={summary} /><div className="content-grid"><AlertCentre alerts={alerts} onSelect={setSelected} /><div className="side-note"><span className="eyebrow">Operator note</span><h3>Watch the margin, not the noise.</h3><p>Forecasts are deliberately conservative. Temporary and unconfirmed spikes are filtered before the trend is fitted; every signal carries its evidence trail.</p><div className="note-rule"></div><span className="mono">READ_ONLY / NO_CONTROL_WRITES</span><DeliveryStatus feed={notificationFeed} /></div></div><Inventory items={items} filters={filters} setFilters={setFilters} onSelect={setSelected} /><footer className="footer"><span>Capacity Intelligence · deterministic local forecast engine</span><span>Latest data {dataset?.last_timestamp || '—'} · {dataset?.label || '—'}</span></footer></main>}{selectedForecast && <div className="detail-overlay" onClick={event => event.target === event.currentTarget && setSelected(null)}><ResourceDetail forecast={selectedForecast} audit={selectedAudit} onClose={() => setSelected(null)} /></div>}</div>
}

class AppErrorBoundary extends Component {
  state = { error: null }
  static getDerivedStateFromError(error) { return { error } }
  componentDidCatch(error, info) { console.error('Capacity Intelligence render error', error, info) }
  render() {
    if (this.state.error) return <div className="error-boundary"><span className="eyebrow">Client render failure</span><h1>Capacity Intelligence could not paint this view.</h1><p>{this.state.error.message}</p><code>Check the browser console for the component stack.</code></div>
    return this.props.children
  }
}

export default function App() {
  return <AppErrorBoundary><DashboardApp /></AppErrorBoundary>
}

const cardItems = [
  ['total_resources', 'Resources monitored', 'resources'],
  ['at_risk', 'At risk', 'risk'],
  ['within_7_days', 'Within 7 days', 'urgent'],
  ['within_30_days', 'Within 30 days', 'soon'],
  ['within_90_days', 'Within 90 days', 'watch'],
]

export default function Cards({ summary }) {
  const validation = summary?.validation_metrics?.chosen_model || {}
  const warning = summary?.false_alarm_rate
  return <section className="card-grid" aria-label="Overview metrics">
    {cardItems.map(([key, label, tone]) => <article className={`metric-card ${tone}`} key={key}>
      <span className="eyebrow">{label}</span>
      <strong>{summary?.[key] ?? '—'}</strong>
      <span className="metric-caption">{key === 'at_risk' ? 'active signals' : 'resources'}</span>
    </article>)}
    <article className="metric-card evidence">
      <span className="eyebrow">Backtest MAE / RMSE</span>
      <strong>{validation.mae ?? 'n/a'} <small>/ {validation.rmse ?? 'n/a'}</small></strong>
      <span className="metric-caption">chosen model · synthetic</span>
    </article>
    <article className="metric-card evidence">
      <span className="eyebrow">False-alarm rate</span>
      <strong>{warning == null ? 'n/a' : `${(warning * 100).toFixed(1)}%`}</strong>
      <span className="metric-caption">median lead time {summary?.median_warning_lead_time ?? 'n/a'} d</span>
    </article>
  </section>
}

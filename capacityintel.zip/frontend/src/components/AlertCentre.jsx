import { AlertTriangle, ArrowUpRight, CalendarClock, ShieldAlert } from 'lucide-react'

function RiskIcon({ level }) { return level === 'Critical' ? <ShieldAlert size={17} /> : <AlertTriangle size={17} /> }

export default function AlertCentre({ alerts, onSelect }) {
  return <section className="panel alert-panel">
    <div className="section-heading"><div><span className="eyebrow">Signal ledger</span><h2>Alert centre</h2></div><span className="section-count">{alerts?.length || 0} active</span></div>
    {!alerts?.length ? <div className="empty-state"><span className="empty-orb"></span><div><strong>No active threshold warnings</strong><p>Stable or unsupported growth is intentionally kept out of the alert stream.</p></div></div> : <div className="alert-list">
      {alerts.map(alert => <article className={`alert-card ${alert.risk_level.toLowerCase().replace(' ', '-')}`} key={alert.alert_id}>
        <div className="alert-topline"><span className="risk-badge"><RiskIcon level={alert.risk_level} />{alert.risk_level}</span><span className="alert-type">{alert.alert_type.replaceAll('_', ' ')}</span><span className="alert-location">{alert.resource} · {alert.rack_location}</span></div>
        <button className="alert-title" onClick={() => onSelect(alert.resource)}>{alert.resource_type} capacity signal <ArrowUpRight size={16} /></button>
        <p className="alert-reason">{alert.reason}. {alert.predicted_crossing_date !== 'not estimable' ? `Projected ${alert.predicted_crossing_date}.` : 'Crossing date not estimable.'}</p>
        <div className="evidence-row">{alert.evidence?.slice(0, 3).map((item, index) => <span key={index}>{item}</span>)}</div>
        <div className="alert-footer"><span><CalendarClock size={14} />{alert.lead_time_days == null ? 'n/a lead time' : `${alert.lead_time_days} days remaining`} · {alert.confidence} confidence</span><span>{alert.likely_contributor}</span></div>
        <div className="action-row"><b>Recommended:</b> {alert.recommended_action}</div>
        {alert.related_events?.length > 0 && <div className="related-events">Related event: {alert.related_events.at(-1).description}</div>}
      </article>)}
    </div>}
  </section>
}

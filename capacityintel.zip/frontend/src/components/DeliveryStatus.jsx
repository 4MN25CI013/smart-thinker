import { CheckCircle2, CircleAlert, Mail, Smartphone } from 'lucide-react'

function ChannelRow({ icon: Icon, label, channel }) {
  const ready = Boolean(channel?.configured)
  return <div className="channel-row">
    <span className="channel-icon"><Icon size={14} /></span>
    <span className="channel-copy"><b>{label}</b><small>{ready ? channel.destination || 'Configured on backend' : 'Setup required'}</small></span>
    <span className={`channel-state ${ready ? 'ready' : 'pending'}`}>{ready ? <CheckCircle2 size={13} /> : <CircleAlert size={13} />}{ready ? 'Ready' : 'Pending'}</span>
  </div>
}

export default function DeliveryStatus({ feed }) {
  const status = feed?.status
  const latest = feed?.items?.[0] || status?.last_deliveries?.[0]
  return <section className="delivery-card" aria-label="Alert delivery status">
    <div className="delivery-heading"><div><span className="eyebrow">Alert delivery</span><h3>Email or mobile</h3></div><span className="delivery-mode">{status?.mode || 'loading'}</span></div>
    <p className="delivery-copy">Forecast warnings can route through backend-only channels. Credentials never reach this dashboard.</p>
    <div className="channel-list">
      <ChannelRow icon={Mail} label="Email" channel={status?.email} />
      <ChannelRow icon={Smartphone} label="Mobile push" channel={status?.mobile} />
    </div>
    <div className="delivery-footnote">{latest ? `Last ${latest.status} · ${latest.provider}` : 'No external delivery configured; local mock is active.'}</div>
  </section>
}

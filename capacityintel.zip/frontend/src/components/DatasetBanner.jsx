export default function DatasetBanner({ dataset, health }) {
  return <div className="dataset-banner">
    <div className="brand-lockup"><span className="brand-mark"><i></i><i></i><i></i></span><span>CAPACITY <b>INTELLIGENCE</b></span></div>
    <div className="dataset-meta">
      <span className={`dataset-pill ${dataset?.label === 'SYNTHETIC' ? 'synthetic' : 'supplied'}`}>{dataset?.label || 'loading'}</span>
      <span>Last data <b>{dataset?.last_timestamp || '—'}</b></span>
      <span>Cleaning <b>{dataset?.validation_status || '—'}</b></span>
      <span>Dropped <b>{dataset?.rows_dropped?.duplicates ?? 0} dup · {dataset?.rows_dropped?.invalid_or_negative ?? 0} invalid</b></span>
      <span>Interpolated <b>{dataset?.gaps_interpolated ?? 0}</b></span>
    </div>
    <div className="advisory"><span className="pulse-dot"></span> Advisory only · read-only · no authentication, not production-secure</div>
    {health?.auth && <div className="auth-note">Auth: not implemented</div>}
  </div>
}

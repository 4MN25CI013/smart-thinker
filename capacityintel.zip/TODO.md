# Capacity Intelligence — Delivery Checklist

## Dataset and cleaning outcome

- [x] Generated 365 daily synthetic telemetry rows per resource/tenant ending 2026-10-27 with seed 7, inventory, events, and a visible `SYNTHETIC` label.
- [x] Injected and cleaned a missing day, one duplicate, one negative value, and invalid values; duplicates are dropped keeping last, invalids are counted, bounded interpolation is counted, and `/api/dataset` exposes the results.
- [x] Preserved the supplied-data path and labels existing non-synthetic files as `supplied`.

## Forecasting and validation outcome

- [x] Implemented causal spike filtering, spike classification, growth-rate change detection, adaptive fit windows, OLS versus damped Holt holdout selection, threshold significance, uncertainty bands/ranges, status ladder, previous forecast, tenant attribution, events, and advisory recommendations.
- [x] Ensured forecast functions accept `as_of` and use only rows up to it; thermal seasonality and resolved spikes do not automatically create unsupported dates.
- [x] Implemented rolling-origin 30-day forecast metrics and warning metrics, with a synthetic-data limitation note and no future-target model-selection leakage.

## Read-only backend outcome

- [x] Provided only GET API routes for health, dataset, summary, resources, forecasts, alerts, events, audit, validation, and tenants; POST/PUT/DELETE return 405.
- [x] Enforced query-scope tenant filtering on totals, forecasts, attribution, events, alerts, and audit. Unknown tenants and out-of-scope resources return 404 without resource details. The prototype explicitly has no authentication, so tenant selection is not production authorization.
- [x] Writes a SQLite `forecast_runs` audit row on startup and every forecast endpoint call with UTC time, scope, model, engine version, data range, SHA-256 fingerprint prefix, status, days, and result JSON.
- [x] Exposes no facility-control automation.

## Alert and notification outcome

- [x] Generates notification title/body/data from genuine forecast alerts with resource, rack, units, utilisation, safety threshold, hard limit, supported estimate, risk, reason, contributor language, recommendation, assessment time, stable IDs, and a tenant-aware deep link.
- [x] Uses resource-specific phrasing, graceful uncertainty wording, alert fingerprints, cooldown/deduplication, severity/fingerprint changes, send/failure history, a local mock provider, and optional backend-only SMTP email and Firebase Cloud Messaging adapters.
- [x] Added an optional backend-only Supabase mirror seam; SQLite remains authoritative. Documented that the workspace began empty, so no existing provider or real phone path could be preserved or phone-tested.
- [x] Forecast endpoint assessment invokes the deduplicated notification path; startup runs a batch snapshot. A future production deployment should move this to a scheduled worker rather than relying on page requests.
- [x] Email/mobile delivery is configurable through backend-only environment values, and the dashboard exposes channel readiness plus recent delivery status without exposing credentials. Actual receipt remains unclaimed until a configured provider succeeds.

## Frontend outcome

- [x] Built the React/Vite/Recharts dashboard with synthetic/supplied banner, concrete cleaning counts, permanent advisory/no-auth notice, viewer selector, API-driven overview cards, severity-sorted Alert Centre, tenant-aware filters, responsive inventory table, and detail panel.
- [x] Shows observed/forecast/bands, safety and hard-limit references, an explicit today marker, changes, holdout scores, 30/60/90 forecasts, previous-vs-updated banner, attribution, events, and audit history.
- [x] Uses explicit risk labels with accessible visual differences, loading/error states, and API-derived numbers only.

## Operational proof outcome

- [x] Added README commands for Windows PowerShell and macOS/Linux, helper scripts, SMTP/Firebase/Supabase setup guidance, and `docs/DEMO_SCRIPT.md`.
- [x] Verified `pytest -q` passes 8/8, `npm run build` succeeds, both dev servers respond, `/manus-routes.json` is valid, the built frontend is served by FastAPI, malformed `as_of` returns 422, and the dashboard renders on desktop and mobile.
- [ ] Real email or mobile delivery remains blocked until the relevant SMTP or Firebase project credentials, recipient address/device token, permissions, and provider configuration are supplied; no real delivery is claimed by the demo default.

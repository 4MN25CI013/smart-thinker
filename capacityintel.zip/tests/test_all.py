from __future__ import annotations

import json
import sqlite3
from pathlib import Path

import numpy as np
import pandas as pd
import pytest
from fastapi.testclient import TestClient

from backend.app import DB_PATH, app
from backend.data import DatasetBundle
from backend.engine import forecast_resource
from backend.notifications import MockProvider, build_notification, notification_status, notify_alert


def bundle_for(values: list[float], resource_type: str = "storage", tenant: str = "acme", threshold: float = 100.0) -> DatasetBundle:
    dates = pd.date_range("2026-01-01", periods=len(values), freq="D")
    inventory = pd.DataFrame([{"resource_id": "TEST-1", "resource_type": resource_type, "rack_id": "R1", "unit": "TB", "capacity_limit": threshold * 1.2, "safety_threshold": threshold}])
    return DatasetBundle(inventory, pd.DataFrame(columns=["date", "resource_id", "tenant_id", "event_type", "description"]), {"TEST-1": {tenant: pd.Series(values, index=dates)}}, {"first_timestamp": dates[0].date().isoformat(), "last_timestamp": dates[-1].date().isoformat()}, "SYNTHETIC")


def test_sustained_growth_estimates_crossing_and_range():
    result = forecast_resource(bundle_for([40 + day * 0.8 for day in range(100)]), "TEST-1")
    assert result["days_remaining"] is not None
    assert result["range"]["low"] <= result["days_remaining"] <= result["range"]["high"] or result["range"]["high"] is None
    assert result["status"] in {"Critical", "High Risk", "Watch"}


def test_flat_series_is_healthy_without_date():
    result = forecast_resource(bundle_for([40.0] * 100), "TEST-1")
    assert result["days_remaining"] is None
    assert result["status"] == "Healthy"
    assert "not estimated" in result["note"]


def test_insufficient_history_is_explicit():
    result = forecast_resource(bundle_for([40 + day for day in range(20)]), "TEST-1")
    assert result["status"] == "Insufficient Data"


def test_no_future_leakage():
    values = [40 + day * 0.2 for day in range(120)]
    original = bundle_for(values)
    changed = bundle_for(values[:-1] + [9999])
    as_of = "2026-03-15"
    left = forecast_resource(original, "TEST-1", as_of=as_of)
    right = forecast_resource(changed, "TEST-1", as_of=as_of)
    assert left["days_remaining"] == right["days_remaining"]
    assert left["current_value"] == right["current_value"]


def test_notification_format_and_deduplication(tmp_path: Path):
    forecast = forecast_resource(bundle_for([40 + day * 0.8 for day in range(100)]), "TEST-1")
    assert forecast["alert"]
    payload = build_notification(forecast["alert"], forecast)
    assert "TEST-1" in payload["title"] or "Storage" in payload["title"]
    assert payload["data"]["alert_id"]
    assert "Recommended action" in payload["body"]
    scoped_forecast = forecast_resource(bundle_for([40 + day * 0.8 for day in range(100)], resource_type="network"), "TEST-1", tenant="acme")
    scoped_payload = build_notification(scoped_forecast["alert"], scoped_forecast)
    assert "Network bandwidth" in scoped_payload["body"]
    assert "tenant=acme" in scoped_payload["data"]["deep_link"]
    db = tmp_path / "notifications.db"
    first = notify_alert(forecast["alert"], forecast, MockProvider(), db)
    second = notify_alert(forecast["alert"], forecast, MockProvider(), db)
    assert first["status"] == "sent"
    assert second["status"] == "deduplicated"


def test_notification_status_masks_channel_secrets(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setenv("NOTIFICATION_CHANNEL", "email")
    monkeypatch.setenv("NOTIFICATION_EMAIL_TO", "ops@example.com")
    monkeypatch.setenv("SMTP_HOST", "smtp.example.com")
    monkeypatch.setenv("SMTP_USERNAME", "smtp-user")
    monkeypatch.setenv("SMTP_PASSWORD", "super-secret")
    status = notification_status(tmp_path / "notifications.db")
    serialized = json.dumps(status)
    assert status["email"]["configured"] is True
    assert status["email"]["destination"] == "o***@example.com"
    assert status["mobile"]["configured"] is False
    assert "super-secret" not in serialized


def test_api_health_summary_resources_alerts_and_read_only():
    with TestClient(app) as client:
        assert client.get("/api/health").json()["read_only"] is True
        summary = client.get("/api/summary").json()
        assert summary["total_resources"] == 10
        assert client.get("/api/resources?resource_type=storage").json()["total"] == 4
        assert client.get("/api/alerts").status_code == 200
        assert client.get("/api/notifications").status_code == 200
        assert client.post("/api/summary").status_code == 405
        assert client.put("/api/summary").status_code == 405
        assert client.delete("/api/summary").status_code == 405


def test_tenant_isolation_and_scoped_not_found():
    with TestClient(app) as client:
        response = client.get("/api/resources?tenant=acme")
        assert response.status_code == 200
        payload = json.dumps(response.json())
        assert "globex" not in payload
        assert client.get("/api/resources/STO-R3-01/forecast?tenant=acme").status_code == 404
        assert client.get("/api/resources/STO-R1-01/forecast?tenant=no-such-tenant").status_code == 404
        events = client.get("/api/events?tenant=acme").json()
        assert all(item["tenant_id"] == "acme" for item in events["items"])


def test_audit_history_grows_for_forecast_endpoint():
    with TestClient(app) as client:
        before = len(client.get("/api/audit?resource_id=STO-R1-01").json()["items"])
        assert client.get("/api/resources/STO-R1-01/forecast").status_code == 200
        after = len(client.get("/api/audit?resource_id=STO-R1-01").json()["items"])
        assert after == before + 1
        row = client.get("/api/audit?resource_id=STO-R1-01").json()["items"][0]
        assert row["input_fingerprint"]
        assert row["engine_version"].startswith("capacity-engine-")

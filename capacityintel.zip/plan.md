# Capacity Intelligence — Implementation Plan

## Scope and approach

Build a local-first, read-only capacity early-warning dashboard for the Smart Thinkers AO-02 hackathon. The primary data path is deterministic Python/FastAPI + Pandas/NumPy + stdlib SQLite so the demo runs without paid APIs, API keys, cloud services, or an external LLM. The data generator creates the requested 365-day synthetic dataset ending 2026-10-27, and the loader documents every cleaning action rather than silently fabricating data.

The forecasting engine will be causal and `as_of`-bounded: clean telemetry, classify temporary/unconfirmed spikes versus level shifts, detect growth-rate changes, fit windowed OLS and damped Holt, select by temporal holdout MAE, estimate safety-threshold crossing only when growth is statistically supported, calculate 95% ranges/bands, attribute recent growth to tenants, and attach related events. Validation will use rolling temporal origins and state clearly that measured results are synthetic and limited.

The latest delivery guidance adds optional email and mobile delivery without weakening the local demo: SQLite remains the default audit/history store and source of truth; `backend/supabase_store.py` exposes a credential-free-compatible seam for a future Supabase deployment; `backend/notifications.py` generates structured alert payloads from real forecasts, keeps the local mock provider as the safe default, and can route to SMTP email, Firebase Cloud Messaging, or both when backend-only configuration is supplied. Credentials and recipients never enter frontend code, provider failures are logged without blocking forecasts, and the dashboard reports channel readiness without exposing secrets. There is no existing repository/provider in this workspace, so no working delivery path can be preserved or claimed as phone-tested.

## Architecture and project structure

- `backend/data.py`: synthetic generation, CSV loading, cleaning, gap interpolation, tenant-scoped views, metadata.
- `backend/engine.py`: causal forecasting, spike/change detection, uncertainty, attribution, alert/recommendation composition, audit fingerprint inputs.
- `backend/validate.py`: rolling-origin backtest and warning metrics.
- `backend/notifications.py`: resource-specific notification templates, alert fingerprinting, cooldown/deduplication, mock/SMTP/Firebase providers, channel readiness, and notification history.
- `backend/supabase_store.py`: optional Supabase REST persistence adapter with safe no-op/local fallback when credentials are absent.
- `backend/app.py`: FastAPI GET-only API, tenant isolation, audit writes, optional frontend static serving.
- `data/`: generated CSVs, dataset label, SQLite audit/notification history.
- `frontend/src/`: React dashboard and small focused components for cards, alerts, inventory, resource details, dataset banner, delivery readiness, and charts.
- `tests/test_all.py`: forecasting, API, isolation, audit, notification, and regression checks.
- `docs/DEMO_SCRIPT.md`: timed walkthrough and honest caveats.

## Design direction

### Alternatives

1. **Control-room noir** — 0.06 probability: dense observability panels, graphite surfaces, and amber/red signal accents.
2. **Arctic operations console** — 0.07 probability: cool blue-black foundation, ice-blue structure, and warm alert beacons.
3. **Editorial infrastructure brief** — 0.04 probability: light paper-like surfaces, strong typography, and report-style evidence blocks.

### Chosen: Arctic operations console

- **Design Movement:** Mission-control observability with calm, technical restraint rather than sci-fi decoration.
- **Core Principles:** evidence before alarm; glanceable hierarchy; high-density but breathable panels; every warning has a next action.
- **Color Philosophy:** deep blue-black backgrounds make signal colors legible; ice-blue indicates system structure and healthy flow; amber/orange/red are reserved for risk and uncertainty.
- **Layout Paradigm:** a persistent left rail establishes context while the main area uses a wide “situation line” header, a responsive card band, then a split alert/inventory work surface and a detail drawer below.
- **Signature Elements:** thin luminous rules; small uppercase section labels with tracking; a compact “signal ledger” treatment for events, evidence, and audit rows.
- **Interaction Philosophy:** selecting a row opens a detail panel without losing the inventory context; filters update immediately; risk is never conveyed by colour alone and always has text/status.
- **Animation:** no heavy motion; use short opacity/translate transitions only for panel reveal and chart loading skeletons, with reduced-motion support.
- **Typography System:** Inter for UI and data, IBM Plex Mono for IDs, timestamps, measurements, and audit fingerprints.
- **Brand Essence:** a quiet operations co-pilot for seeing capacity trouble before it becomes an outage; precise, cautious, actionable.
- **Brand Voice:** headlines sound direct and measured; CTAs sound advisory. Example lines: “Watch the margin, not the noise.” and “Open evidence trail”.
- **Wordmark & Logo:** a compact vertical gauge mark beside the wordmark, built from three unequal bars representing current use, safety margin, and hard limit.
- **Signature Brand Color:** ice cyan `#86d9ff`, used sparingly for active state and structural highlights.

## Build and verification workflow

1. Generate the small project files and register host diagnostics for Python, JavaScript, JSON, and CSS before application code edits.
2. Create the Python virtual environment and install `requirements.txt`; install frontend packages using the pinned npm/pnpm-compatible manifest.
3. Generate data, initialize audit tables, run a startup forecast batch, and run pytest.
4. Build the React frontend and verify `GET /manus-routes.json` plus backend API smoke calls.
5. Run backend on `127.0.0.1:8000` and Vite on `0.0.0.0:5173` with `/api` proxy; serve `frontend/dist` from FastAPI when built.
6. Use the managed preview on port 5173 for visual delivery; only claim email or mobile delivery when the relevant backend configuration is supplied and an explicit send succeeds. Otherwise show mock/readiness state without claiming receipt.
7. Keep only GET routes public; no facility-control writes, no secrets in source, and document SMTP/Firebase/Supabase setup separately from the local default.

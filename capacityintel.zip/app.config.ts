export default { logoUrl: "https://cdn.simpleicons.org/grafana/86d9ff" }

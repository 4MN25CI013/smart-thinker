# Capacity Intelligence

**Seeing trouble before the capacity runs out.** Smart Thinkers · UG-13.9 · AO-02 AI-Ops track.

Capacity Intelligence is a local-first, read-only capacity early-warning prototype for storage, power, thermal, network, and VM resources. It generates clearly labeled synthetic telemetry, cleans it with visible counts, forecasts operational-threshold crossings with causal deterministic models, explains the evidence, and keeps an audit trail. It is intentionally advisory: it never writes to power, cooling, network, procurement, billing, or facility controls.

## Important security and data note

This demo has **no authentication**. `?tenant=` simulates a tenant session and backend tenant isolation is enforced, but it is not production-secure. The synthetic dataset is not production telemetry. The local SQLite audit database is the default source of truth.

This workspace started empty, so there was no existing mobile notification provider or generic-message implementation to trace or preserve. Notification content is now generated from genuine forecast alert objects using resource-specific templates, stable alert/resource IDs, structured payload data, cooldown/deduplication, and send/failure history. The default provider is a local mock. An optional backend-only Firebase Admin adapter is enabled only when credentials and `FCM_DEVICE_TOKEN` are configured; the frontend never receives Firebase service credentials. An optional `SupabaseMirror` can mirror forecast-run metadata when `SUPABASE_URL` and a backend key are present, while SQLite remains authoritative for the local demo.

## Run locally

### macOS / Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cd frontend && npm install && cd ..
python -m pytest -q
(cd frontend && npm run build)
uvicorn backend.app:app --host 127.0.0.1 --port 8000
# in a second terminal, from the project root:
cd frontend && npm run dev
```

Open `http://localhost:5173`. The Vite dev server proxies `/api` to `http://127.0.0.1:8000`. After `npm run build`, FastAPI also serves `frontend/dist` at `/`; run only Uvicorn for the one-process demo.

### Windows PowerShell

```powershell
py -3 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
Push-Location frontend; npm install; Pop-Location
python -m pytest -q
Push-Location frontend; npm run build; Pop-Location
python -m uvicorn backend.app:app --host 127.0.0.1 --port 8000
# in a second PowerShell window, from the project root:
Set-Location frontend; npm run dev
```

For a one-command helper, use `bash scripts/run_dev.sh` on macOS/Linux or `./scripts/run_dev.ps1` in PowerShell. The helper starts the backend and Vite frontend and cleans up both on exit.

## Optional email and mobile delivery

The local default uses a mock provider and never claims that a real message was received. Set `NOTIFICATION_CHANNEL=auto` (the default) to use every fully configured channel, or choose `email`, `mobile`, `both`, or `mock` explicitly. Delivery is triggered by the existing forecast assessment path and remains deduplicated by alert, scope, fingerprint, provider, and cooldown window.

### Email via SMTP

Set these backend-only values before starting Uvicorn. A normal SMTP relay, Gmail app password, or transactional email provider can be used; the frontend never receives these values.

```bash
export NOTIFICATION_CHANNEL=email
export NOTIFICATION_EMAIL_TO='you@example.com'
export NOTIFICATION_EMAIL_FROM='capacity-intelligence@example.com'
export SMTP_HOST='smtp.example.com'
export SMTP_PORT='587'
export SMTP_USERNAME='smtp-user'
export SMTP_PASSWORD='backend-only-secret'
export SMTP_STARTTLS='true'
```

### Mobile push via Firebase Cloud Messaging

To manually test Firebase delivery, install the optional SDK in the backend environment (`pip install firebase-admin`), create an FCM device token in the actual mobile/PWA client, and set backend-only environment variables before starting Uvicorn:

```bash
export FIREBASE_SERVICE_ACCOUNT_JSON='{"type":"service_account", ...}'
export FCM_DEVICE_TOKEN='device-token-from-the-client'
```

A file path can be used instead of JSON with `FIREBASE_CREDENTIALS_PATH`. Never commit either value or expose them in React. The backend sends a title, concise mobile body, and structured data (`alert_id`, `resource_id`, risk, scope, assessment date, and a tenant-aware dashboard deep link). In the current workspace there is no mobile client, service worker, device token, or Firebase project configuration, so no real phone send is claimed. A production client still needs Firebase project setup, notification permissions, token refresh/invalid-token handling, and a deep-link route appropriate to its platform.

The dashboard reads `/api/notifications` to show whether email or mobile is ready and the latest provider result. That endpoint masks configured email recipients and never returns SMTP passwords, Firebase credentials, or device tokens. Provider failures are recorded in SQLite and do not block forecast responses.

## Optional Supabase mirror

The app remains runnable without Supabase. For a deployment that wants a Supabase mirror, provide `SUPABASE_URL` and backend-only `SUPABASE_SERVICE_ROLE_KEY` (or a deliberately scoped `SUPABASE_ANON_KEY`) plus a `forecast_runs` table matching the audit fields. The mirror is best-effort and never blocks forecasting. Do not place service-role keys in frontend code. The local SQLite schema is created automatically in `data/audit.db`.

## API surface

Only GET routes are exposed: `/api/health`, `/api/dataset`, `/api/summary`, `/api/resources`, `/api/resources/{id}/forecast`, `/api/alerts`, `/api/events`, `/api/audit`, `/api/validation`, `/api/tenants`, and `/api/notifications`. POST, PUT, and DELETE return 405. `/api/health` explicitly reports `read_only: true` and `auth: not implemented - not production-secure`.

The default generated resources are designed to exercise the logic: VM-R3-01, STO-R1-01, and PWR-R2-01 should be the most urgent; NET-R1-01 should be a watch; flat, seasonal, cleaned-spike, and post-cleanup series should not invent dates. Forecasts use a 60-day window, causal spike/change detection, OLS and damped Holt holdout scoring, and honest uncertainty. The validation panel never claims accuracy or outage reduction beyond measured synthetic backtests.

## Project structure

`backend/data.py` owns generation and cleaning; `backend/engine.py` owns deterministic forecasts; `backend/validate.py` owns rolling-origin validation; `backend/notifications.py` owns alert content, dedupe, mock/SMTP/FCM providers, channel readiness, and history; `backend/supabase_store.py` is the optional mirror seam; `backend/app.py` exposes the GET-only API and audit rows. `frontend/src/` contains the React dashboard and focused components. `tests/test_all.py` covers forecasting, tenant isolation, API read-only behavior, audit growth, notification content/deduplication, and no-future-leakage. See `docs/DEMO_SCRIPT.md` for the walkthrough.

# Capacity Intelligence — 5-minute demo script

## 0:00 — Set the frame

Open the dashboard and point to the top banner: the dataset is synthetic, the last timestamp is visible, cleaning counts are not hidden, and the permanent notice says advisory only, read-only, no authentication, not production-secure. Say that the system is designed to see a trend early without pretending a forecast is certainty.

## 0:45 — Start with the signal ledger

Show the Alert centre sorted by severity, then lead time. Open the highest-risk resource. Read one evidence bullet aloud: current use versus the operational threshold, hard limit, weekly growth, and the selected model. Call out that the alert text says “likely contributor — association only, causation not established” and shows logged events rather than inventing a cause.

## 1:45 — Open the forecast evidence

In the detail panel, show the solid observed line, dashed forecast, shaded 95% band, amber safety threshold, red hard limit, today context, and purple change markers. Compare the 30/60/90-day values and intervals. Explain that a date is withheld when the slope is not statistically supported; the engine does not turn a seasonal thermal curve or a resolved spike into an outage prediction.

## 2:45 — Show the inventory and tenant isolation

Return to the inventory. Filter by risk, rack, and type. Change “Viewing as” from Operator to one tenant. Explain that every request carries the tenant scope and the backend excludes other tenants from totals, resources, attribution, events, alerts, and audit. Try a resource that has no data for that tenant if time allows; it returns a scoped 404 rather than revealing that the resource exists.

## 3:30 — Show the audit trail and validation

Open a detail panel and point to audit fingerprints, time, model, engine version, and data range. Call `/api/validation` or use the overview cards to show the rolling-origin metrics and false-alarm rate. State the boundary clearly: these are synthetic results with a few designed events, not a production accuracy or outage-reduction claim.

## 4:15 — Explain notifications

Explain that the generic messages “triggered”, “Hello”, and “Chethu” could not be traced because this workspace was empty and contained no existing provider code. The replacement path builds notification title/body/data directly from the genuine forecast alert, adds a resource-specific recommendation, stable alert ID, deep link, cooldown/dedupe, and notification history. The local default uses a mock provider. Firebase Admin is optional and backend-only; no real phone notification is claimed until a Firebase project, client token, permissions, and manual send are configured.

## 4:45 — Close on safety

End with the read-only promise: no POST/PUT/DELETE API routes, no facility-control code, no procurement, no billing, and no credential exposure in the frontend. The operational action is advisory capacity planning with a 6–10 week hardware lead time, not an automated control decision.

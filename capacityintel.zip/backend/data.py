from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import hashlib
import json

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "data"

RESOURCE_DEFS = [
    {"resource_id": "STO-R1-01", "resource_type": "storage", "rack_id": "R1", "unit": "TB", "capacity_limit": 1000.0, "safety_threshold": 900.0},
    {"resource_id": "STO-R2-01", "resource_type": "storage", "rack_id": "R2", "unit": "TB", "capacity_limit": 1000.0, "safety_threshold": 900.0},
    {"resource_id": "STO-R3-01", "resource_type": "storage", "rack_id": "R3", "unit": "TB", "capacity_limit": 1000.0, "safety_threshold": 900.0},
    {"resource_id": "STO-R4-01", "resource_type": "storage", "rack_id": "R4", "unit": "TB", "capacity_limit": 1000.0, "safety_threshold": 900.0},
    {"resource_id": "PWR-R1-01", "resource_type": "power", "rack_id": "R1", "unit": "kW", "capacity_limit": 10.0, "safety_threshold": 8.5},
    {"resource_id": "PWR-R2-01", "resource_type": "power", "rack_id": "R2", "unit": "kW", "capacity_limit": 10.0, "safety_threshold": 8.5},
    {"resource_id": "TMP-R2-01", "resource_type": "thermal", "rack_id": "R2", "unit": "C", "capacity_limit": 32.0, "safety_threshold": 27.0},
    {"resource_id": "NET-R1-01", "resource_type": "network", "rack_id": "R1", "unit": "Gbps", "capacity_limit": 100.0, "safety_threshold": 80.0},
    {"resource_id": "NET-R3-01", "resource_type": "network", "rack_id": "R3", "unit": "Gbps", "capacity_limit": 100.0, "safety_threshold": 80.0},
    {"resource_id": "VM-R3-01", "resource_type": "vm", "rack_id": "R3", "unit": "count", "capacity_limit": 500.0, "safety_threshold": 475.0},
]
TENANTS = ["acme", "globex", "initech", "umbra"]
START_DATE = pd.Timestamp("2025-10-28")
END_DATE = pd.Timestamp("2026-10-27")

# Each entry is (start day, base value, [(change day, slope/day), ...]).
COMPONENTS: dict[str, dict[str, tuple[int, float, list[tuple[int, float]]]]] = {
    "STO-R1-01": {"acme": (0, 300, [(0, 0.9)]), "globex": (240, 60, [(240, 1.4)])},
    "STO-R2-01": {"acme": (0, 300, [(0, 0.0)]), "initech": (0, 100, [(0, 0.02)])},
    "STO-R3-01": {"initech": (0, 200, [(0, 1.0)]), "umbra": (0, 100, [(0, 0.3)])},
    "STO-R4-01": {"globex": (0, 600, [(0, 1.5), (205, -2.0), (245, 0.3)])},
    "PWR-R1-01": {"acme": (0, 3, [(0, 0.004)]), "globex": (0, 2.5, [(0, 0.002)])},
    "PWR-R2-01": {"umbra": (0, 2, [(0, 0.004)]), "initech": (0, 1.5, [(0, 0.003), (260, 0.02)])},
    "TMP-R2-01": {"acme": (0, 22, [(0, 0.0)])},
    "NET-R1-01": {"globex": (0, 20, [(0, 0.05), (280, 0.2)]), "acme": (0, 10, [(0, 0.03)])},
    "NET-R3-01": {"umbra": (0, 30, [(0, 0.0)])},
    "VM-R3-01": {"acme": (0, 150, [(0, 0.2)]), "globex": (0, 120, [(0, 0.3), (300, 0.5)])},
}

EVENTS = [
    ("2026-02-26", "STO-R1-01", "globex", "tenant_onboarding", "Globex onboarding on storage R1"),
    ("2026-03-23", "PWR-R2-01", "initech", "workload_change", "Initech workload change on power R2"),
    ("2026-07-24", "STO-R4-01", "globex", "policy_change", "Retention tightened on storage R4"),
    ("2026-07-30", "STO-R4-01", "globex", "capacity_incident", "Storage R4 crossed its operating threshold"),
    ("2026-08-07", "NET-R1-01", "globex", "workload_change", "Globex replication increased on network R1"),
    ("2026-09-26", "VM-R3-01", "globex", "tenant_onboarding", "Globex VM expansion on R3"),
    ("2026-10-12", "PWR-R1-01", "acme", "maintenance", "Acme load test on power R1"),
]


@dataclass
class DatasetBundle:
    inventory: pd.DataFrame
    events: pd.DataFrame
    tenant_series: dict[str, dict[str, pd.Series]]
    info: dict[str, Any]
    label: str

    @property
    def resources(self) -> list[str]:
        return self.inventory["resource_id"].tolist()

    @property
    def tenants(self) -> list[str]:
        names = {tenant for resource in self.tenant_series.values() for tenant in resource}
        return sorted(names or TENANTS)

    def has_scope(self, resource_id: str, tenant: str | None) -> bool:
        if resource_id not in self.tenant_series:
            return False
        if tenant is None:
            return True
        return tenant in self.tenant_series[resource_id]

    def series(self, resource_id: str, tenant: str | None = None, as_of: str | pd.Timestamp | None = None) -> pd.Series:
        if resource_id not in self.tenant_series:
            return pd.Series(dtype=float)
        parts = self.tenant_series[resource_id]
        selected = [parts[tenant]] if tenant is not None and tenant in parts else ([] if tenant else list(parts.values()))
        if tenant is not None and not selected:
            return pd.Series(dtype=float)
        if not selected:
            return pd.Series(dtype=float)
        frame = pd.concat(selected, axis=1)
        result = frame.sum(axis=1, min_count=1).dropna().sort_index()
        if as_of is not None:
            result = result.loc[result.index <= pd.Timestamp(as_of)]
        return result

    def fingerprint(self, resource_id: str, tenant: str | None = None, as_of: str | pd.Timestamp | None = None) -> str:
        values = self.series(resource_id, tenant, as_of)
        raw = json.dumps([(str(idx.date()), round(float(value), 6)) for idx, value in values.items()], separators=(",", ":"))
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16]


def _component_value(day: int, start: int, base: float, slopes: list[tuple[int, float]]) -> float:
    if day < start:
        return 0.0
    ordered = sorted(slopes)
    value = base
    for index, (change_day, slope) in enumerate(ordered):
        segment_start = max(start, change_day)
        segment_end = day if index == len(ordered) - 1 else min(day, ordered[index + 1][0])
        if segment_end > segment_start:
            value += slope * (segment_end - segment_start)
    return max(0.0, value)


def generate_synthetic_data(data_dir: Path = DATA_DIR) -> None:
    data_dir.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(7)
    days = pd.date_range(START_DATE, END_DATE, freq="D")
    rows: list[dict[str, Any]] = []
    for resource_id, tenant_map in COMPONENTS.items():
        for tenant_id, (start, base, slopes) in tenant_map.items():
            for day, timestamp in enumerate(days):
                value = _component_value(day, start, base, slopes)
                if resource_id == "TMP-R2-01":
                    value += 2.0 * np.sin(2 * np.pi * day / 365)
                if resource_id == "PWR-R1-01" and tenant_id == "acme" and day in (330, 331):
                    value += 2.0
                if resource_id == "NET-R3-01" and tenant_id == "umbra" and day in (350, 351):
                    value += 45.0
                noise = rng.normal(0.0, max(abs(value), 0.5) * 0.004)
                rows.append({"timestamp": timestamp.strftime("%Y-%m-%d"), "resource_id": resource_id, "tenant_id": tenant_id, "value": round(max(0.0, value + noise), 6)})
    raw = pd.DataFrame(rows)
    # Deliberate quality issues used by the loader tests and demo banner.
    raw = pd.concat([raw, raw.iloc[[0]].copy()], ignore_index=True)
    raw.loc[(raw["resource_id"] == "STO-R2-01") & (raw["tenant_id"] == "acme") & (raw["timestamp"] == "2026-04-15"), "value"] = np.nan
    raw = raw.drop(raw[(raw["resource_id"] == "STO-R2-01") & (raw["tenant_id"] == "acme") & (raw["timestamp"] == "2026-04-15")].index[:1]).reset_index(drop=True)
    raw.loc[(raw["resource_id"] == "PWR-R2-01") & (raw["tenant_id"] == "umbra") & (raw["timestamp"] == "2026-06-01"), "value"] = -1.0
    raw.to_csv(data_dir / "telemetry.csv", index=False)
    pd.DataFrame(RESOURCE_DEFS).to_csv(data_dir / "inventory.csv", index=False)
    pd.DataFrame(EVENTS, columns=["date", "resource_id", "tenant_id", "event_type", "description"]).to_csv(data_dir / "events.csv", index=False)
    (data_dir / "DATASET_LABEL.txt").write_text("SYNTHETIC — generated locally with NumPy seed 7; no production telemetry.\n", encoding="utf-8")


def _read_or_generate(data_dir: Path) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, str]:
    data_dir.mkdir(parents=True, exist_ok=True)
    label_file = data_dir / "DATASET_LABEL.txt"
    files = [data_dir / name for name in ("telemetry.csv", "inventory.csv", "events.csv")]
    if not all(path.exists() for path in files):
        generate_synthetic_data(data_dir)
    label = label_file.read_text(encoding="utf-8").strip() if label_file.exists() else "supplied"
    telemetry = pd.read_csv(files[0])
    inventory = pd.read_csv(files[1])
    events = pd.read_csv(files[2])
    return telemetry, inventory, events, ("SYNTHETIC" if "SYNTHETIC" in label.upper() else "supplied")


def load_dataset(data_dir: Path = DATA_DIR) -> DatasetBundle:
    telemetry, inventory, events, label = _read_or_generate(data_dir)
    raw_rows = len(telemetry)
    telemetry["timestamp"] = pd.to_datetime(telemetry["timestamp"], errors="coerce")
    duplicate_mask = telemetry.duplicated(subset=["timestamp", "resource_id", "tenant_id"], keep="last")
    duplicate_rows = int(duplicate_mask.sum())
    telemetry = telemetry.loc[~duplicate_mask].copy()
    invalid_mask = telemetry["timestamp"].isna() | telemetry["value"].isna() | (telemetry["value"] < 0)
    invalid_rows = int(invalid_mask.sum())
    telemetry = telemetry.loc[~invalid_mask].copy()
    telemetry["value"] = telemetry["value"].astype(float)

    full_dates = pd.date_range(telemetry["timestamp"].min(), telemetry["timestamp"].max(), freq="D")
    tenant_series: dict[str, dict[str, pd.Series]] = {}
    gaps_interpolated = 0
    for (resource_id, tenant_id), group in telemetry.groupby(["resource_id", "tenant_id"]):
        series = group.set_index("timestamp")["value"].sort_index().reindex(full_dates)
        before = series.isna()
        filled = series.interpolate(limit=3, limit_area="inside")
        gaps_interpolated += int((before & filled.notna()).sum())
        tenant_series.setdefault(resource_id, {})[tenant_id] = filled

    inventory["capacity_limit"] = inventory["capacity_limit"].astype(float)
    inventory["safety_threshold"] = inventory["safety_threshold"].astype(float)
    events["date"] = pd.to_datetime(events["date"], errors="coerce")
    info = {
        "rows_input": raw_rows,
        "rows_loaded": int(len(telemetry)),
        "duplicate_rows_dropped": duplicate_rows,
        "invalid_rows_dropped": invalid_rows,
        "gaps_interpolated": gaps_interpolated,
        "last_timestamp": telemetry["timestamp"].max().date().isoformat(),
        "first_timestamp": telemetry["timestamp"].min().date().isoformat(),
        "validation_status": "cleaned with documented drops and bounded interpolation",
        "resources": int(len(inventory)),
    }
    return DatasetBundle(inventory=inventory, events=events, tenant_series=tenant_series, info=info, label=label)


def resource_meta(bundle: DatasetBundle, resource_id: str) -> dict[str, Any]:
    match = bundle.inventory[bundle.inventory["resource_id"] == resource_id]
    if match.empty:
        raise KeyError(resource_id)
    row = match.iloc[0]
    return {key: (float(value) if key in {"capacity_limit", "safety_threshold"} else value) for key, value in row.to_dict().items()}

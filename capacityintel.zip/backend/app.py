from __future__ import annotations

from contextlib import asynccontextmanager
from datetime import date, datetime, timezone
import json
import sqlite3
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles

from .data import DATA_DIR, DatasetBundle, load_dataset
from .engine import ENGINE_VERSION, SEVERITY_ORDER, forecast_resource, resource_row
from .notifications import init_notification_db, notification_history, notification_status, notify_alert
from .supabase_store import SupabaseMirror
from .validate import run_validation

DB_PATH = DATA_DIR / "audit.db"
_bundle: DatasetBundle | None = None
_validation: dict[str, Any] | None = None


def _init_audit_db() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS forecast_runs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                run_at TEXT NOT NULL,
                resource_id TEXT NOT NULL,
                tenant_scope TEXT NOT NULL,
                model TEXT NOT NULL,
                engine_version TEXT NOT NULL,
                data_start TEXT NOT NULL,
                data_end TEXT NOT NULL,
                input_fingerprint TEXT NOT NULL,
                status TEXT NOT NULL,
                days_remaining INTEGER,
                result_json TEXT NOT NULL
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_forecast_runs_resource ON forecast_runs(resource_id, tenant_scope)")
    init_notification_db(DB_PATH)


def _state() -> tuple[DatasetBundle, dict[str, Any]]:
    global _bundle, _validation
    if _bundle is None:
        _bundle = load_dataset()
        _init_audit_db()
    if _validation is None:
        _validation = run_validation(_bundle)
    return _bundle, _validation


def _validate_tenant(tenant: str | None) -> None:
    if tenant is not None and tenant not in _state()[0].tenants:
        raise HTTPException(status_code=404, detail="tenant not found")


def _get_forecast(resource_id: str, tenant: str | None, as_of: str | None = None) -> dict[str, Any]:
    bundle, _ = _state()
    _validate_tenant(tenant)
    if resource_id not in bundle.resources or not bundle.has_scope(resource_id, tenant):
        raise HTTPException(status_code=404, detail="resource not found in the requested scope")
    try:
        return forecast_resource(bundle, resource_id, tenant, as_of=as_of)
    except (KeyError, ValueError) as exc:
        raise HTTPException(status_code=404, detail="resource forecast unavailable") from exc


def _audit_forecast(forecast: dict[str, Any]) -> None:
    bundle, _ = _state()
    scope = forecast["tenant_scope"]
    tenant = None if scope == "operator" else scope
    now = datetime.now(timezone.utc).isoformat()
    result_json = json.dumps({
        "forecast": forecast,
        "range": forecast["range"],
        "confidence": forecast["confidence"],
        "changes": forecast["changes"],
        "previous_forecast": forecast["previous_forecast"],
    }, separators=(",", ":"))
    record = {
        "run_at": now,
        "resource_id": forecast["resource"]["resource_id"],
        "tenant_scope": scope,
        "model": forecast["method"],
        "engine_version": ENGINE_VERSION,
        "data_start": bundle.info["first_timestamp"],
        "data_end": forecast["as_of"],
        "input_fingerprint": bundle.fingerprint(forecast["resource"]["resource_id"], tenant, forecast["as_of"]),
        "status": forecast["status"],
        "days_remaining": forecast["days_remaining"],
        "result_json": result_json,
    }
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("INSERT INTO forecast_runs(run_at, resource_id, tenant_scope, model, engine_version, data_start, data_end, input_fingerprint, status, days_remaining, result_json) VALUES (:run_at, :resource_id, :tenant_scope, :model, :engine_version, :data_start, :data_end, :input_fingerprint, :status, :days_remaining, :result_json)", record)
    SupabaseMirror().mirror_forecast({key: value for key, value in record.items() if key != "result_json"} | {"result_json": result_json})


def _startup_batch() -> None:
    bundle, _ = _state()
    # One immutable, local audit snapshot per resource at startup; notifications are deduplicated.
    for resource_id in bundle.resources:
        forecast = forecast_resource(bundle, resource_id, include_previous=False)
        _audit_forecast(forecast)
        if forecast.get("alert"):
            notify_alert(forecast["alert"], forecast)


@asynccontextmanager
async def lifespan(_: FastAPI):
    _state()
    _startup_batch()
    yield


app = FastAPI(title="Capacity Intelligence", version="1.0.0", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:5173", "http://localhost:8000"], allow_credentials=False, allow_methods=["GET"], allow_headers=["*"])


@app.get("/api/health")
def health() -> dict[str, Any]:
    return {"status": "ok", "read_only": True, "auth": "not implemented - not production-secure", "dataset": _state()[0].label}


@app.get("/api/dataset")
def dataset(tenant: str | None = Query(default=None)) -> dict[str, Any]:
    _validate_tenant(tenant)
    bundle, _ = _state()
    return {"label": bundle.label, "last_timestamp": bundle.info["last_timestamp"], "first_timestamp": bundle.info["first_timestamp"], "rows_dropped": {"duplicates": bundle.info["duplicate_rows_dropped"], "invalid_or_negative": bundle.info["invalid_rows_dropped"]}, "gaps_interpolated": bundle.info["gaps_interpolated"], "rows_input": bundle.info["rows_input"], "rows_loaded": bundle.info["rows_loaded"], "validation_status": bundle.info["validation_status"], "tenant_scope": tenant or "operator", "notice": "SYNTHETIC data is for demonstration only" if bundle.label == "SYNTHETIC" else "supplied data loaded from data/"}


@app.get("/api/summary")
def summary(tenant: str | None = Query(default=None)) -> dict[str, Any]:
    _validate_tenant(tenant)
    bundle, validation = _state()
    rows = [resource_row(bundle, resource_id, tenant) for resource_id in bundle.resources if bundle.has_scope(resource_id, tenant)]
    days = [row["days_remaining"] for row in rows if row["days_remaining"] is not None]
    counts = {status: sum(row["status"] == status for row in rows) for status in SEVERITY_ORDER}
    at_risk = sum(row["status"] in {"Critical", "High Risk", "Watch"} for row in rows)
    warning = validation["warning_metrics"]
    return {"tenant_scope": tenant or "operator", "total_resources": len(rows), "at_risk": at_risk, "within_7_days": sum(day <= 7 for day in days), "within_30_days": sum(day <= 30 for day in days), "within_90_days": sum(day <= 90 for day in days), "counts_by_status": counts, "median_warning_lead_time": warning["warning_lead_time_days"], "validation_metrics": validation["forecast_metrics"], "false_alarm_rate": warning["false_alarm_rate"], "dataset": {"label": bundle.label, "last_timestamp": bundle.info["last_timestamp"], "validation_status": bundle.info["validation_status"]}}


@app.get("/api/resources")
def resources(tenant: str | None = Query(default=None), resource_type: str | None = None, rack: str | None = None, risk: str | None = None, q: str | None = None, sort: str = "risk", limit: int = Query(default=50, ge=1, le=100), offset: int = Query(default=0, ge=0)) -> dict[str, Any]:
    _validate_tenant(tenant)
    bundle, _ = _state()
    rows = [resource_row(bundle, resource_id, tenant) for resource_id in bundle.resources if bundle.has_scope(resource_id, tenant)]
    if resource_type:
        rows = [row for row in rows if row["resource_type"] == resource_type]
    if rack:
        rows = [row for row in rows if row["rack_id"] == rack]
    if risk:
        rows = [row for row in rows if row["status"] == risk]
    if q:
        q_lower = q.lower()
        rows = [row for row in rows if q_lower in row["resource_id"].lower() or q_lower in row["resource_type"].lower() or q_lower in row["rack_id"].lower()]
    if sort == "days":
        rows.sort(key=lambda row: row["days_remaining"] if row["days_remaining"] is not None else 99999)
    elif sort == "utilisation":
        rows.sort(key=lambda row: row["utilisation_pct"], reverse=True)
    elif sort == "growth":
        rows.sort(key=lambda row: row["growth_per_week"], reverse=True)
    else:
        rows.sort(key=lambda row: (SEVERITY_ORDER.get(row["status"], 9), row["days_remaining"] if row["days_remaining"] is not None else 99999))
    return {"items": rows[offset : offset + limit], "total": len(rows), "limit": limit, "offset": offset, "tenant_scope": tenant or "operator"}


@app.get("/api/resources/{resource_id}/forecast")
def resource_forecast(resource_id: str, tenant: str | None = Query(default=None), as_of: date | None = None) -> dict[str, Any]:
    forecast = _get_forecast(resource_id, tenant, as_of.isoformat() if as_of else None)
    _audit_forecast(forecast)
    if forecast.get("alert"):
        notify_alert(forecast["alert"], forecast)
    return forecast


@app.get("/api/alerts")
def alerts(tenant: str | None = Query(default=None), limit: int = Query(default=50, ge=1, le=100)) -> dict[str, Any]:
    _validate_tenant(tenant)
    bundle, _ = _state()
    result: list[dict[str, Any]] = []
    for resource_id in bundle.resources:
        if bundle.has_scope(resource_id, tenant):
            forecast = forecast_resource(bundle, resource_id, tenant, include_previous=False)
            if forecast.get("alert"):
                result.append(forecast["alert"])
    result.sort(key=lambda alert: (SEVERITY_ORDER.get(alert["risk_level"], 9), alert["lead_time_days"] if alert["lead_time_days"] is not None else 99999))
    return {"items": result[:limit], "total": len(result), "tenant_scope": tenant or "operator"}


@app.get("/api/events")
def events(tenant: str | None = Query(default=None), resource_id: str | None = None) -> dict[str, Any]:
    _validate_tenant(tenant)
    bundle, _ = _state()
    frame = bundle.events.copy()
    if resource_id:
        if resource_id not in bundle.resources or not bundle.has_scope(resource_id, tenant):
            raise HTTPException(status_code=404, detail="resource not found in the requested scope")
        frame = frame[frame["resource_id"] == resource_id]
    if tenant:
        frame = frame[frame["tenant_id"] == tenant]
    items = [{"date": row["date"].date().isoformat(), "resource_id": row["resource_id"], "tenant_id": row["tenant_id"], "event_type": row["event_type"], "description": row["description"]} for _, row in frame.sort_values("date", ascending=False).iterrows()]
    return {"items": items, "tenant_scope": tenant or "operator"}


@app.get("/api/audit")
def audit(tenant: str | None = Query(default=None), resource_id: str | None = None, limit: int = Query(default=50, ge=1, le=200)) -> dict[str, Any]:
    _validate_tenant(tenant)
    if resource_id and (resource_id not in _state()[0].resources or not _state()[0].has_scope(resource_id, tenant)):
        raise HTTPException(status_code=404, detail="resource not found in the requested scope")
    query = "SELECT id, run_at, resource_id, tenant_scope, model, engine_version, data_start, data_end, input_fingerprint, status, days_remaining FROM forecast_runs WHERE 1=1"
    params: list[Any] = []
    if tenant:
        query += " AND tenant_scope = ?"
        params.append(tenant)
    if resource_id:
        query += " AND resource_id = ?"
        params.append(resource_id)
    query += " ORDER BY id DESC LIMIT ?"
    params.append(limit)
    with sqlite3.connect(DB_PATH) as conn:
        conn.row_factory = sqlite3.Row
        items = [dict(row) for row in conn.execute(query, params).fetchall()]
    return {"items": items, "tenant_scope": tenant or "operator"}


@app.get("/api/validation")
def validation() -> dict[str, Any]:
    return _state()[1]


@app.get("/api/tenants")
def tenants() -> dict[str, Any]:
    return {"items": _state()[0].tenants, "notice": "There is no authentication; tenant selection simulates a tenant session and is not production-secure."}


@app.get("/api/notifications")
def notifications(limit: int = Query(default=20, ge=1, le=100)) -> dict[str, Any]:
    return {"status": notification_status(DB_PATH), "items": notification_history(DB_PATH, limit)}


frontend_dist = Path(__file__).resolve().parent.parent / "frontend" / "dist"
if frontend_dist.exists():
    app.mount("/", StaticFiles(directory=frontend_dist, html=True), name="frontend")

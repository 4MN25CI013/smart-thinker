from __future__ import annotations

import json
import os
from typing import Any
from urllib import request


class SupabaseMirror:
    """Optional mirror for deployments that provide Supabase URL/key/table settings.

    Local SQLite remains authoritative. This adapter never sends facility-control commands.
    """

    def __init__(self) -> None:
        self.url = os.getenv("SUPABASE_URL", "").rstrip("/")
        self.key = os.getenv("SUPABASE_SERVICE_ROLE_KEY") or os.getenv("SUPABASE_ANON_KEY", "")
        self.table = os.getenv("SUPABASE_FORECAST_TABLE", "forecast_runs")

    @property
    def enabled(self) -> bool:
        return bool(self.url and self.key)

    def mirror_forecast(self, record: dict[str, Any]) -> tuple[bool, str | None]:
        if not self.enabled:
            return False, "Supabase mirror disabled; local SQLite is authoritative"
        endpoint = f"{self.url}/rest/v1/{self.table}"
        body = json.dumps(record).encode("utf-8")
        req = request.Request(endpoint, data=body, method="POST", headers={"apikey": self.key, "Authorization": f"Bearer {self.key}", "Content-Type": "application/json", "Prefer": "return=minimal"})
        try:
            with request.urlopen(req, timeout=4) as response:
                return 200 <= response.status < 300, None if 200 <= response.status < 300 else f"HTTP {response.status}"
        except Exception as exc:
            return False, type(exc).__name__ + ": Supabase mirror failed"

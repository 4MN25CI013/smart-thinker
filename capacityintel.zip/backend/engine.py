from __future__ import annotations

from datetime import timedelta
from typing import Any

import numpy as np
import pandas as pd

from .data import DatasetBundle, resource_meta

ENGINE_VERSION = "capacity-engine-1.0.0"
SEVERITY_ORDER = {"Critical": 0, "High Risk": 1, "Watch": 2, "Healthy": 3, "Insufficient Data": 4}


def _ols(series: pd.Series) -> dict[str, float]:
    y = series.to_numpy(dtype=float)
    x = np.arange(len(y), dtype=float)
    if len(y) < 2 or np.ptp(x) == 0:
        return {"slope": 0.0, "intercept": float(y[-1]) if len(y) else 0.0, "se": float("inf"), "sigma": 0.0, "mae": float("inf")}
    slope, intercept = np.polyfit(x, y, 1)
    pred = intercept + slope * x
    residuals = y - pred
    sxx = float(np.sum((x - x.mean()) ** 2))
    sigma = float(np.sqrt(np.sum(residuals**2) / max(1, len(y) - 2)))
    se = float(sigma / np.sqrt(sxx)) if sxx else float("inf")
    return {"slope": float(slope), "intercept": float(intercept), "se": se, "sigma": sigma, "mae": float(np.mean(np.abs(residuals)))}


def _holt(values: np.ndarray, horizon: int) -> np.ndarray:
    if len(values) == 0:
        return np.zeros(horizon)
    alpha, beta, phi = 0.3, 0.1, 0.98
    level = float(values[0])
    trend = float(values[1] - values[0]) if len(values) > 1 else 0.0
    for value in values[1:]:
        previous_level = level
        level = alpha * value + (1 - alpha) * (level + phi * trend)
        trend = beta * (level - previous_level) + (1 - beta) * phi * trend
    return np.array([level + sum(phi**i for i in range(1, step + 1)) * trend for step in range(1, horizon + 1)], dtype=float)


def _spike_groups(flags: pd.Series) -> list[list[pd.Timestamp]]:
    groups: list[list[pd.Timestamp]] = []
    current: list[pd.Timestamp] = []
    for date, flagged in flags.items():
        if bool(flagged):
            if current and (date - current[-1]).days > 1:
                groups.append(current)
                current = []
            current.append(date)
        elif current:
            groups.append(current)
            current = []
    if current:
        groups.append(current)
    return groups


def detect_spikes(series: pd.Series) -> tuple[pd.Series, list[dict[str, Any]]]:
    series = series.sort_index().astype(float)
    prior_median = series.shift(1).rolling(7, min_periods=1).median()
    prior_median = prior_median.fillna(series.expanding().median().shift(1)).fillna(series.iloc[0])
    deviation = series - prior_median
    spread = 1.4826 * deviation.abs().shift(1).rolling(30, min_periods=3).median()
    threshold = np.maximum(4 * spread.fillna(0).to_numpy(), 0.01 * prior_median.abs().to_numpy())
    flags = pd.Series(np.abs(deviation.to_numpy()) > threshold, index=series.index)
    cleaned = series.copy()
    changes: list[dict[str, Any]] = []
    for group in _spike_groups(flags):
        start, end = group[0], group[-1]
        pre = series.loc[: start - pd.Timedelta(days=1)].tail(5)
        post = series.loc[end + pd.Timedelta(days=1) :].head(5)
        pre_mean = float(pre.mean()) if len(pre) else float(series.loc[start])
        post_mean = float(post.mean()) if len(post) else None
        magnitude = float(series.loc[group].mean() - pre_mean)
        if len(post) < 3:
            classification = "unconfirmed_spike"
        elif abs(float(post_mean) - pre_mean) < 0.5 * max(abs(magnitude), 1e-9):
            classification = "temporary_spike"
        else:
            classification = "level_shift"
        if classification in {"temporary_spike", "unconfirmed_spike"}:
            cleaned.loc[group] = prior_median.loc[group].to_numpy()
        changes.append({"date": start.date().isoformat(), "end_date": end.date().isoformat(), "type": classification, "magnitude": round(magnitude, 4), "pre_mean": round(pre_mean, 4), "post_mean": round(post_mean, 4) if post_mean is not None else None})
    return cleaned, changes


def detect_growth_changes(series: pd.Series) -> list[dict[str, Any]]:
    series = series.dropna().sort_index()
    flags: list[dict[str, Any]] = []
    last_flag: pd.Timestamp | None = None
    if len(series) < 35:
        return flags
    for position in range(28, len(series), 3):
        current_date = series.index[position]
        if last_flag is not None and (current_date - last_flag).days < 14:
            continue
        recent = series.iloc[position - 14 : position + 1]
        prior = series.iloc[position - 28 : position - 14]
        a = _ols(recent)
        c = _ols(prior)
        difference = abs(a["slope"] - c["slope"])
        combined_se = np.sqrt(a["se"] ** 2 + c["se"] ** 2)
        larger = max(abs(a["slope"]), abs(c["slope"]), 1e-9)
        if difference > 4 * max(combined_se, 1e-9) and difference >= 0.2 * larger:
            flags.append({"date": current_date.date().isoformat(), "type": "growth_rate_change", "old_slope_per_day": round(c["slope"], 6), "new_slope_per_day": round(a["slope"], 6), "slope_change": round(a["slope"] - c["slope"], 6)})
            last_flag = current_date
    return flags


def _holdout_scores(series: pd.Series, fit_window: int) -> dict[str, Any]:
    values = series.tail(fit_window).to_numpy(dtype=float)
    holdout = min(14, max(0, len(values) // 4))
    if len(values) < 28 or holdout < 7:
        return {"ols_mae": None, "holt_mae": None, "chosen": "OLS"}
    train, actual = values[:-holdout], values[-holdout:]
    ols_train = _ols(pd.Series(train))
    x = np.arange(len(train), len(train) + holdout)
    ols_pred = ols_train["intercept"] + ols_train["slope"] * x
    holt_pred = _holt(train, holdout)
    ols_mae = float(np.mean(np.abs(actual - ols_pred)))
    holt_mae = float(np.mean(np.abs(actual - holt_pred)))
    return {"ols_mae": round(ols_mae, 6), "holt_mae": round(holt_mae, 6), "chosen": "OLS" if ols_mae <= holt_mae else "damped Holt"}


def _crossing(meta: dict[str, Any], current: float, fit: dict[str, float], as_of: pd.Timestamp) -> dict[str, Any]:
    threshold = float(meta["safety_threshold"])
    gap = threshold - current
    if gap <= 0:
        return {"days_remaining": 0, "crossing_date": as_of.date().isoformat(), "range": {"low": 0, "point": 0, "high": 0}, "note": "already at or above the operational safety threshold"}
    slope, se = fit["slope"], fit["se"]
    supported = slope > 0 and np.isfinite(se) and slope / max(se, 1e-12) > 2.5
    if not supported:
        return {"days_remaining": None, "crossing_date": None, "range": {"low": None, "point": None, "high": None}, "note": "no statistically supported growth; exhaustion date not estimated"}
    point = max(0, int(np.ceil(gap / slope)))
    upper_slope = slope + 1.96 * se
    lower_slope = slope - 1.96 * se
    low = max(0, int(np.floor(gap / upper_slope))) if upper_slope > 0 else None
    high = int(np.ceil(gap / lower_slope)) if lower_slope > 0 else None
    return {"days_remaining": point, "crossing_date": (as_of + pd.Timedelta(days=point)).date().isoformat(), "range": {"low": low, "point": point, "high": high}, "note": "supported by positive OLS growth"}


def _confidence(rng: dict[str, Any], point: int | None) -> str:
    if point is None or rng.get("high") is None or rng.get("low") is None or point == 0:
        return "Low" if point is None else "High"
    relative_width = (rng["high"] - rng["low"]) / max(point, 1)
    return "High" if relative_width < 0.3 else "Medium" if relative_width < 1.0 else "Low"


def _recommendation(resource_type: str) -> str:
    return {
        "storage": "Review retention and backup policies, clean up where safe, and start capacity planning given 6–10 week hardware lead time.",
        "network": "Investigate sustained bandwidth growth, rebalance workloads, and review uplink headroom.",
        "power": "Review rack demand growth, PDU/circuit headroom, and recent load changes.",
        "thermal": "Review thermal trend versus the safety margin, airflow, containment, and equipment placement.",
        "vm": "Evaluate workload allocation and licence headroom before the VM ceiling tightens.",
    }.get(resource_type, "Review the trend and operating margin with the facility team.")


def _attribution(bundle: DatasetBundle, resource_id: str, tenant: str | None, as_of: pd.Timestamp) -> tuple[list[dict[str, Any]], str, list[dict[str, Any]]]:
    end = as_of
    start = as_of - pd.Timedelta(days=30)
    rows: list[dict[str, Any]] = []
    for tenant_id, series in bundle.tenant_series.get(resource_id, {}).items():
        if tenant is not None and tenant_id != tenant:
            continue
        recent = series.loc[start:end].dropna()
        if len(recent) >= 2:
            change = float(recent.iloc[-1] - recent.iloc[0])
        else:
            change = 0.0
        rows.append({"tenant_id": tenant_id, "change": round(change, 4), "positive": round(max(0.0, change), 4)})
    total_positive = sum(row["positive"] for row in rows)
    for row in rows:
        row["share_of_positive_growth"] = round(row["positive"] / total_positive, 4) if total_positive else 0.0
    rows.sort(key=lambda row: row["positive"], reverse=True)
    contributor = rows[0]["tenant_id"] if rows and rows[0]["positive"] > 0 else "cause unknown"
    event_rows = []
    if not bundle.events.empty:
        selected = bundle.events[(bundle.events["resource_id"] == resource_id) & (bundle.events["date"] <= end)]
        if tenant is not None:
            selected = selected[selected["tenant_id"] == tenant]
        for _, row in selected.tail(8).iterrows():
            event_rows.append({"date": row["date"].date().isoformat(), "resource_id": row["resource_id"], "tenant_id": row["tenant_id"], "event_type": row["event_type"], "description": row["description"]})
    return rows, contributor, event_rows


def _status(current: float, threshold: float, days: int | None, observations: int) -> str:
    if observations < 30:
        return "Insufficient Data"
    if current >= threshold or (days is not None and days <= 14):
        return "Critical"
    if days is not None and days <= 30:
        return "High Risk"
    if days is not None and days <= 90:
        return "Watch"
    return "Healthy"


def forecast_resource(bundle: DatasetBundle, resource_id: str, tenant: str | None = None, as_of: str | pd.Timestamp | None = None, include_previous: bool = True) -> dict[str, Any]:
    if not bundle.has_scope(resource_id, tenant):
        raise KeyError(resource_id)
    series = bundle.series(resource_id, tenant, as_of)
    if series.empty:
        raise KeyError(resource_id)
    meta = resource_meta(bundle, resource_id)
    as_of_date = series.index.max()
    cleaned, spike_changes = detect_spikes(series)
    growth_changes = detect_growth_changes(cleaned)
    changes = sorted(spike_changes + growth_changes, key=lambda row: row["date"])
    latest_change_date = pd.Timestamp(changes[-1]["date"]) if changes else None
    fit_days = 60
    if latest_change_date is not None and (as_of_date - latest_change_date).days <= 60:
        fit_days = int(np.clip((as_of_date - latest_change_date).days, 14, 60))
    fit_series = cleaned.tail(min(fit_days, len(cleaned)))
    fit = _ols(fit_series)
    scores = _holdout_scores(cleaned, min(fit_days, len(cleaned)))
    current = float(series.iloc[-1])
    crossing = _crossing(meta, current, fit, as_of_date)
    days_remaining = crossing["days_remaining"]
    confidence = _confidence(crossing["range"], days_remaining)
    status = _status(current, float(meta["safety_threshold"]), days_remaining, len(series))
    attribution, contributor, event_rows = _attribution(bundle, resource_id, tenant, as_of_date)
    last_30 = cleaned.tail(30)
    sigma = max(float(fit["sigma"]), 0.0)
    forecast_path: list[dict[str, Any]] = []
    point_path = _holt(fit_series.to_numpy(dtype=float), 365) if scores["chosen"] == "damped Holt" else np.array([fit["intercept"] + fit["slope"] * (len(fit_series) - 1 + h) for h in range(1, 366)])
    for horizon, value in enumerate(point_path, 1):
        band = 1.96 * np.sqrt(sigma**2 + (fit["se"] * horizon) ** 2) if np.isfinite(fit["se"]) else None
        forecast_path.append({"date": (as_of_date + pd.Timedelta(days=horizon)).date().isoformat(), "value": round(float(value), 4), "lower": round(float(value - band), 4) if band is not None else None, "upper": round(float(value + band), 4) if band is not None else None})
    observed = [{"date": idx.date().isoformat(), "value": round(float(value), 4)} for idx, value in last_30.items()]
    points = {}
    for horizon in (30, 60, 90):
        item = forecast_path[horizon - 1]
        points[str(horizon)] = {"date": item["date"], "value": item["value"], "lower": item["lower"], "upper": item["upper"]}
    risk_reason = "sustained growth" if days_remaining is not None else "no statistically supported growth"
    if any(item["type"] in {"temporary_spike", "unconfirmed_spike"} for item in changes[-3:]):
        risk_reason += "; recent spike was filtered as transient or unconfirmed"
    alert_type = "sustained_growth" if days_remaining is not None else ("possible_spike_unconfirmed" if any(item["type"] == "unconfirmed_spike" for item in changes[-3:]) else "regime_change" if growth_changes else "sustained_growth")
    alert = None
    if status in {"Critical", "High Risk", "Watch"}:
        alert = {
            "alert_id": f"{resource_id}:{tenant or 'operator'}:{as_of_date.date().isoformat()}",
            "resource": resource_id,
            "resource_type": meta["resource_type"],
            "rack_location": meta["rack_id"],
            "risk_level": status,
            "alert_type": alert_type,
            "predicted_crossing_date": crossing["crossing_date"] or "not estimable",
            "lead_time_days": days_remaining,
            "range": crossing["range"],
            "confidence": confidence,
            "evidence": [
                f"Current use is {current / float(meta['safety_threshold']) * 100:.1f}% of the operational safety threshold ({current:.2f} {meta['unit']} / {meta['safety_threshold']:.2f} {meta['unit']}).",
                f"Weekly growth is {fit['slope'] * 7:.3f} {meta['unit']}/week from the selected {len(fit_series)}-day window.",
                f"Method: {scores['chosen']}; OLS holdout MAE {scores['ols_mae'] if scores['ols_mae'] is not None else 'n/a'}, Holt holdout MAE {scores['holt_mae'] if scores['holt_mae'] is not None else 'n/a'}.",
                f"Hard capacity limit is {meta['capacity_limit']:.2f} {meta['unit']}; threshold estimate remains advisory only.",
            ],
            "reason": risk_reason,
            "related_events": event_rows,
            "likely_contributor": f"{contributor} — likely contributor - association only, causation not established" if contributor != "cause unknown" else "cause unknown",
            "recommended_action": _recommendation(meta["resource_type"]),
            "assessed_at": as_of_date.isoformat(),
            "tenant_scope": tenant or "operator",
        }
    previous = None
    if include_previous and latest_change_date is not None and 0 < (as_of_date - latest_change_date).days <= 60:
        previous = forecast_resource(bundle, resource_id, tenant, latest_change_date - pd.Timedelta(days=1), include_previous=False)
        previous = {"as_of": previous["as_of"], "days_remaining": previous["days_remaining"], "status": previous["status"], "confidence": previous["confidence"]}
    return {
        "resource": meta,
        "tenant_scope": tenant or "operator",
        "as_of": as_of_date.date().isoformat(),
        "current_value": round(current, 4),
        "utilisation_pct_of_threshold": round(current / float(meta["safety_threshold"]) * 100, 2),
        "utilisation_pct_of_limit": round(current / float(meta["capacity_limit"]) * 100, 2),
        "observations": len(series),
        "status": status,
        "days_remaining": days_remaining,
        "crossing_date": crossing["crossing_date"],
        "range": crossing["range"],
        "confidence": confidence,
        "note": crossing["note"],
        "weekly_growth": round(fit["slope"] * 7, 6),
        "slope_per_day": round(fit["slope"], 8),
        "slope_standard_error": round(fit["se"], 8) if np.isfinite(fit["se"]) else None,
        "method": scores["chosen"],
        "method_scores": scores,
        "observed": observed,
        "forecast_path": forecast_path,
        "forecast_points": points,
        "changes": changes,
        "attribution": attribution,
        "events": event_rows,
        "alert": alert,
        "previous_forecast": previous,
        "engine_version": ENGINE_VERSION,
    }


def resource_row(bundle: DatasetBundle, resource_id: str, tenant: str | None = None) -> dict[str, Any]:
    result = forecast_resource(bundle, resource_id, tenant, include_previous=False)
    return {
        "resource_id": resource_id,
        "resource_type": result["resource"]["resource_type"],
        "rack_id": result["resource"]["rack_id"],
        "unit": result["resource"]["unit"],
        "current_value": result["current_value"],
        "safety_threshold": result["resource"]["safety_threshold"],
        "capacity_limit": result["resource"]["capacity_limit"],
        "utilisation_pct": result["utilisation_pct_of_threshold"],
        "growth_per_week": result["weekly_growth"],
        "days_remaining": result["days_remaining"],
        "status": result["status"],
        "confidence": result["confidence"],
        "tenant_scope": result["tenant_scope"],
    }

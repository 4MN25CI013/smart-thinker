from __future__ import annotations

from datetime import datetime, timezone
from email.message import EmailMessage
import hashlib
import importlib
import json
import os
import smtplib
import sqlite3
from pathlib import Path
from typing import Any, Protocol

DB_PATH = Path(__file__).resolve().parent.parent / "data" / "audit.db"


class NotificationProvider(Protocol):
    name: str

    def send(self, payload: dict[str, Any]) -> tuple[bool, str | None]: ...


class MockProvider:
    name = "local-mock"

    def send(self, payload: dict[str, Any]) -> tuple[bool, str | None]:
        return True, None


class EmailProvider:
    name = "smtp-email"

    def __init__(self, recipient: str | None = None):
        self.recipient = recipient or os.getenv("NOTIFICATION_EMAIL_TO")

    def send(self, payload: dict[str, Any]) -> tuple[bool, str | None]:
        host = os.getenv("SMTP_HOST")
        if not self.recipient:
            return False, "NOTIFICATION_EMAIL_TO is not configured"
        if not host:
            return False, "SMTP_HOST is not configured"
        sender = os.getenv("NOTIFICATION_EMAIL_FROM") or os.getenv("SMTP_USERNAME")
        if not sender:
            return False, "NOTIFICATION_EMAIL_FROM or SMTP_USERNAME is not configured"
        try:
            message = EmailMessage()
            message["Subject"] = payload["title"]
            message["From"] = sender
            message["To"] = self.recipient
            message.set_content(payload["body"])
            port = int(os.getenv("SMTP_PORT", "587"))
            use_tls = os.getenv("SMTP_STARTTLS", "true").lower() not in {"0", "false", "no", "off"}
            smtp_client = smtplib.SMTP_SSL if port == 465 else smtplib.SMTP
            with smtp_client(host, port, timeout=15) as client:
                if use_tls and port != 465:
                    client.starttls()
                username = os.getenv("SMTP_USERNAME")
                password = os.getenv("SMTP_PASSWORD")
                if username and password:
                    client.login(username, password)
                client.send_message(message)
            return True, None
        except Exception as exc:  # Provider errors must not stop forecasting.
            return False, type(exc).__name__ + ": delivery failed"


class FirebaseProvider:
    name = "firebase-cloud-messaging"

    def __init__(self, token: str | None = None):
        self.token = token or os.getenv("FCM_DEVICE_TOKEN")

    def send(self, payload: dict[str, Any]) -> tuple[bool, str | None]:
        if not self.token:
            return False, "FCM_DEVICE_TOKEN is not configured"
        try:
            firebase_admin = importlib.import_module("firebase_admin")
            credentials = importlib.import_module("firebase_admin.credentials")
            messaging = importlib.import_module("firebase_admin.messaging")
            if not firebase_admin._apps:
                service_json = os.getenv("FIREBASE_SERVICE_ACCOUNT_JSON")
                service_path = os.getenv("FIREBASE_CREDENTIALS_PATH")
                if service_json:
                    cred = credentials.Certificate(json.loads(service_json))
                elif service_path:
                    cred = credentials.Certificate(service_path)
                else:
                    return False, "Firebase credentials are not configured"
                firebase_admin.initialize_app(cred)
            message = messaging.Message(
                notification=messaging.Notification(title=payload["title"], body=payload["body"]),
                data={key: str(value) for key, value in payload.get("data", {}).items()},
                token=self.token,
            )
            messaging.send(message)
            return True, None
        except Exception as exc:  # Provider errors must not stop forecasting.
            return False, type(exc).__name__ + ": delivery failed"


def init_notification_db(path: Path = DB_PATH) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(path) as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS notification_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                alert_id TEXT NOT NULL,
                recipient_scope TEXT NOT NULL,
                fingerprint TEXT NOT NULL,
                sent_at TEXT NOT NULL,
                provider TEXT NOT NULL,
                status TEXT NOT NULL,
                failure_reason TEXT,
                payload_json TEXT NOT NULL
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_notification_dedupe ON notification_history(alert_id, recipient_scope, fingerprint)")


def _resource_label(resource_type: str) -> str:
    return {"storage": "Storage", "network": "Network", "power": "Power", "thermal": "Cooling / Temperature", "vm": "VM capacity"}.get(resource_type, resource_type.title())


def _format_days(days: int | None) -> str:
    return "the estimate is unavailable" if days is None else "today" if days == 0 else f"approximately {days} days"


def build_notification(alert: dict[str, Any], forecast: dict[str, Any]) -> dict[str, Any]:
    resource = forecast["resource"]
    label = _resource_label(resource["resource_type"])
    current = forecast["current_value"]
    threshold = resource["safety_threshold"]
    limit = resource["capacity_limit"]
    unit = resource["unit"]
    contributor = alert.get("likely_contributor")
    reason = alert.get("reason", "a capacity risk was detected")
    action = alert.get("recommended_action", "Review the trend and operating margin.")
    template_lead = {
        "storage": "Storage headroom is tightening.",
        "network": "Network bandwidth is approaching its operating margin.",
        "power": "Rack demand is eroding electrical headroom.",
        "thermal": "Cooling margin is tightening against the operating temperature.",
        "vm": "VM allocation is approaching its safe operating ceiling.",
    }.get(resource["resource_type"], "Capacity headroom is tightening.")
    title_prefix = "Critical Capacity Risk" if alert["risk_level"] == "Critical" else "Capacity Warning"
    title = f"{title_prefix}: {label} — {resource['rack_id']}"
    contributor_text = f" Likely contributor: {contributor}." if contributor and contributor != "cause unknown" else ""
    body = (f"{template_lead} {resource['resource_id']} is at {current / threshold * 100:.0f}% of its safety threshold "
            f"({current:.2f} {unit} of {threshold:.2f} {unit}; hard limit {limit:.2f} {unit}). "
            f"Risk is {alert['risk_level']}; {_format_days(forecast['days_remaining'])} to the operating threshold. "
            f"Reason: {reason}.{contributor_text} Recommended action: {action} "
            f"Assessed {forecast['as_of']}. Open Capacity Intelligence for evidence and the trend.")
    alert_id = alert.get("alert_id") or f"{resource['resource_id']}:{forecast['tenant_scope']}:{forecast['as_of']}"
    fingerprint_source = json.dumps({"alert_id": alert_id, "risk": alert["risk_level"], "days": forecast["days_remaining"], "reason": reason}, sort_keys=True)
    fingerprint = hashlib.sha256(fingerprint_source.encode()).hexdigest()[:16]
    return {
        "title": title,
        "body": body,
        "data": {
            "alert_id": alert_id,
            "resource_id": resource["resource_id"],
            "risk_level": alert["risk_level"],
            "alert_type": alert.get("alert_type", "sustained_growth"),
            "tenant_scope": forecast["tenant_scope"],
            "deep_link": f"/?resource={resource['resource_id']}{'&tenant=' + forecast['tenant_scope'] if forecast['tenant_scope'] != 'operator' else ''}",
            "assessed_at": forecast["as_of"],
        },
        "fingerprint": fingerprint,
    }


def _email_configured() -> bool:
    return bool(os.getenv("NOTIFICATION_EMAIL_TO") and os.getenv("SMTP_HOST") and (os.getenv("NOTIFICATION_EMAIL_FROM") or os.getenv("SMTP_USERNAME")))


def _mobile_configured() -> bool:
    return bool(os.getenv("FCM_DEVICE_TOKEN") and (os.getenv("FIREBASE_SERVICE_ACCOUNT_JSON") or os.getenv("FIREBASE_CREDENTIALS_PATH")))


def _channel_mode() -> str:
    mode = os.getenv("NOTIFICATION_CHANNEL", "auto").strip().lower()
    return mode if mode in {"auto", "mock", "email", "mobile", "both"} else "auto"


def _providers() -> list[NotificationProvider]:
    mode = _channel_mode()
    if mode == "mock":
        return [MockProvider()]
    if mode == "email":
        return [EmailProvider()]
    if mode == "mobile":
        return [FirebaseProvider()]
    if mode == "both":
        return [EmailProvider(), FirebaseProvider()]
    selected: list[NotificationProvider] = []
    if _email_configured():
        selected.append(EmailProvider())
    if _mobile_configured():
        selected.append(FirebaseProvider())
    return selected or [MockProvider()]


def _masked_email(value: str | None) -> str | None:
    if not value or "@" not in value:
        return None
    local, domain = value.split("@", 1)
    return f"{local[:1]}***@{domain}"


def notification_status(path: Path = DB_PATH) -> dict[str, Any]:
    init_notification_db(path)
    mode = _channel_mode()
    active = _providers()
    email_to = os.getenv("NOTIFICATION_EMAIL_TO")
    with sqlite3.connect(path) as conn:
        conn.row_factory = sqlite3.Row
        rows = conn.execute("SELECT sent_at, provider, status, failure_reason FROM notification_history ORDER BY id DESC LIMIT 5").fetchall()
    return {
        "mode": mode,
        "active_providers": [provider.name for provider in active],
        "email": {
            "configured": _email_configured(),
            "destination": _masked_email(email_to),
            "setup": "Set NOTIFICATION_EMAIL_TO, SMTP_HOST, and NOTIFICATION_EMAIL_FROM or SMTP_USERNAME.",
        },
        "mobile": {
            "configured": _mobile_configured(),
            "destination": "FCM device token configured" if os.getenv("FCM_DEVICE_TOKEN") else None,
            "setup": "Set FCM_DEVICE_TOKEN and Firebase Admin credentials on the backend.",
        },
        "last_deliveries": [dict(row) for row in rows],
    }


def notification_history(path: Path = DB_PATH, limit: int = 20) -> list[dict[str, Any]]:
    init_notification_db(path)
    with sqlite3.connect(path) as conn:
        conn.row_factory = sqlite3.Row
        rows = conn.execute("SELECT id, alert_id, recipient_scope, sent_at, provider, status, failure_reason, payload_json FROM notification_history ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    items = []
    for row in rows:
        payload = json.loads(row["payload_json"])
        items.append({
            "id": row["id"],
            "alert_id": row["alert_id"],
            "resource_id": payload.get("data", {}).get("resource_id"),
            "risk_level": payload.get("data", {}).get("risk_level"),
            "recipient_scope": row["recipient_scope"],
            "sent_at": row["sent_at"],
            "provider": row["provider"],
            "status": row["status"],
            "failure_reason": row["failure_reason"],
            "title": payload.get("title"),
        })
    return items


def notify_alert(alert: dict[str, Any], forecast: dict[str, Any], provider: NotificationProvider | None = None, path: Path = DB_PATH, cooldown_hours: int = 24) -> dict[str, Any]:
    init_notification_db(path)
    providers = [provider] if provider is not None else _providers()
    payload = build_notification(alert, forecast)
    scope = str(forecast["tenant_scope"])
    now = datetime.now(timezone.utc)
    deliveries: list[dict[str, Any]] = []
    for current_provider in providers:
        recipient_scope = f"{scope}:{current_provider.name}"
        with sqlite3.connect(path) as conn:
            previous = conn.execute("SELECT sent_at, status FROM notification_history WHERE alert_id=? AND recipient_scope=? AND fingerprint=? ORDER BY id DESC LIMIT 1", (payload["data"]["alert_id"], recipient_scope, payload["fingerprint"])).fetchone()
            if previous:
                age_hours = (now - datetime.fromisoformat(previous[0])).total_seconds() / 3600
                if age_hours < cooldown_hours and previous[1] in {"sent", "deduplicated"}:
                    deliveries.append({"provider": current_provider.name, "status": "deduplicated"})
                    continue
            ok, error = current_provider.send(payload)
            status = "sent" if ok else "failed"
            conn.execute("INSERT INTO notification_history(alert_id, recipient_scope, fingerprint, sent_at, provider, status, failure_reason, payload_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?)", (payload["data"]["alert_id"], recipient_scope, payload["fingerprint"], now.isoformat(), current_provider.name, status, error, json.dumps(payload)))
            deliveries.append({"provider": current_provider.name, "status": status, "failure_reason": error})
    statuses = [delivery["status"] for delivery in deliveries]
    if statuses and all(status == "deduplicated" for status in statuses):
        overall_status = "deduplicated"
    elif any(status == "sent" for status in statuses) and any(status == "failed" for status in statuses):
        overall_status = "partial"
    elif any(status == "sent" for status in statuses):
        overall_status = "sent"
    else:
        overall_status = "failed"
    return {
        "status": overall_status,
        "provider": ",".join(delivery["provider"] for delivery in deliveries),
        "payload": payload,
        "deliveries": deliveries,
    }

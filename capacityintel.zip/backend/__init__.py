"""Capacity Intelligence local backend."""

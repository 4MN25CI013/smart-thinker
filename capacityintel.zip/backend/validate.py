from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd

from .data import DatasetBundle
from .engine import _holt, _ols, forecast_resource


def _metric_rows(actual: list[float], predicted: list[float]) -> dict[str, float | None]:
    if not actual:
        return {"mae": None, "rmse": None}
    errors = np.asarray(actual) - np.asarray(predicted)
    return {"mae": round(float(np.mean(np.abs(errors))), 4), "rmse": round(float(np.sqrt(np.mean(errors**2))), 4)}


def _crossing_day(series: pd.Series, threshold: float) -> pd.Timestamp | None:
    crossed = series[series >= threshold]
    return crossed.index[0] if not crossed.empty else None


def run_validation(bundle: DatasetBundle) -> dict[str, Any]:
    chosen_actual: list[float] = []
    chosen_pred: list[float] = []
    ols_actual: list[float] = []
    ols_pred: list[float] = []
    holt_actual: list[float] = []
    holt_pred: list[float] = []
    naive_actual: list[float] = []
    naive_pred: list[float] = []
    warnings_issued = 0
    false_alarms = 0
    lead_times: list[int] = []
    historical_crossings = 0
    origins_evaluated = 0

    for resource_id in bundle.resources:
        series = bundle.series(resource_id)
        meta = bundle.inventory[bundle.inventory["resource_id"] == resource_id].iloc[0]
        if len(series) < 90:
            continue
        threshold = float(meta["safety_threshold"])
        crossing = _crossing_day(series, threshold)
        historical_crossings += int(crossing is not None)
        start = 60
        for origin in range(start, len(series) - 30, 7):
            train = series.iloc[:origin]
            actual_point = float(series.iloc[origin + 29])
            fit_window = train.tail(min(60, len(train)))
            fit = _ols(fit_window)
            x = len(fit_window) - 1 + 30
            ols_value = fit["intercept"] + fit["slope"] * x
            holt_value = float(_holt(fit_window.to_numpy(dtype=float), 30)[-1])
            last_value = float(train.iloc[-1])
            # Model selection must be based only on data available at the origin.
            selection = forecast_resource(bundle, resource_id, as_of=train.index[-1], include_previous=False)["method"]
            chosen = ols_value if selection == "OLS" else holt_value
            chosen_actual.append(actual_point)
            chosen_pred.append(chosen)
            ols_actual.append(actual_point)
            ols_pred.append(ols_value)
            holt_actual.append(actual_point)
            holt_pred.append(holt_value)
            naive_actual.append(actual_point)
            naive_pred.append(last_value)
            origins_evaluated += 1

            future = series.iloc[origin : min(origin + 90, len(series))]
            future_crossing = _crossing_day(future, threshold)
            projected = None
            if fit["slope"] > 0 and np.isfinite(fit["se"]) and fit["slope"] / max(fit["se"], 1e-12) > 2.5:
                gap = threshold - last_value
                if gap <= 0:
                    projected = 0
                else:
                    projected = int(np.ceil(gap / fit["slope"]))
            if projected is not None and projected <= 90:
                warnings_issued += 1
                if future_crossing is None:
                    false_alarms += 1
                else:
                    lead_times.append(max(0, (future_crossing - train.index[-1]).days))

    warning_rate = round(false_alarms / warnings_issued, 4) if warnings_issued else None
    return {
        "dataset_note": "Results come from synthetic data with few designed events; they do not establish production accuracy or outage reduction.",
        "origins_evaluated": origins_evaluated,
        "forecast_metrics": {
            "chosen_model": _metric_rows(chosen_actual, chosen_pred),
            "ols_alone": _metric_rows(ols_actual, ols_pred),
            "damped_holt_alone": _metric_rows(holt_actual, holt_pred),
            "naive_last_value": _metric_rows(naive_actual, naive_pred),
        },
        "warning_metrics": {
            "historical_crossings": historical_crossings,
            "warning_lead_time_days": round(float(np.median(lead_times)), 2) if lead_times else None,
            "warnings_issued": warnings_issued,
            "false_alarms": false_alarms,
            "false_alarm_rate": warning_rate,
            "note": "Warning lead time is computed only where a threshold crossing was observable within the next 90 days; n/a means no computable cases.",
        },
    }
